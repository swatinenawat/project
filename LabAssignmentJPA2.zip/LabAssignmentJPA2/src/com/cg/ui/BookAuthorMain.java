package com.cg.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entities.Author;
import com.cg.entities.Book;

public class BookAuthorMain {

	static EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");;
	static EntityManager em=emf.createEntityManager();
	static Scanner sc=null;
	public static void main(String[] args) 
	{
		
		sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("1: Display All Books\t2: Search books by author name\t3: Search books with given price range\t4 : Search author name\t5: Exit");
			System.out.println("Enter your choice");
			int c=sc.nextInt();
			switch(c)
			{
				case 1: displayBook();break;
				case 2: displayByAuthor();break;
				case 3: displayPriceRange();break;
				case 4: displayAuthorName();break;
				
		      default: System.exit(0);
			}
		}


	}
	public static void displayBook()
	{
		String sqry="SELECT book from Book book";
		TypedQuery<Book> query = em.createQuery(sqry,Book.class);
		List<Book> bookList=query.getResultList();
		Iterator<Book> it=bookList.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	
	public static void displayByAuthor()
	{
		sc=new Scanner(System.in);
		System.out.println("Enter Author Name : ");
		String authorName=sc.next();
		String sqry="SELECT b from Book b,BookAuthor bookauthor WHERE b.isbn=bookauthor.book AND bookauthor.author in (SELECT a.id FROM Author a WHERE a.name=:nm)" ;
		TypedQuery<Book> query = em.createQuery(sqry,Book.class);
		query.setParameter("nm", authorName);
		List<Book> bookList=query.getResultList();
		Iterator<Book> it=bookList.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	public static void displayPriceRange()
	{
		sc=new Scanner(System.in);
		System.out.println("Enter Price Range : ");
		double lprice=sc.nextDouble();
		double hprice=sc.nextDouble();
		String sqry="SELECT b from Book b WHERE b.price BETWEEN :low AND :high" ;
		TypedQuery<Book> query = em.createQuery(sqry,Book.class);
		query.setParameter("low", lprice);
		query.setParameter("high", hprice);
		List<Book> bookList=query.getResultList();
		Iterator<Book> it=bookList.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	public static void displayAuthorName()
	{
		sc=new Scanner(System.in);
		System.out.println("Enter Book Id : ");
		int bookId=sc.nextInt();
		String sqry="SELECT a from Author a,BookAuthor ba WHERE a.id=ba.author AND ba.book=:bid" ;
		TypedQuery<Author> query = em.createQuery(sqry,Author.class);
		query.setParameter("bid", bookId);
		List<Author> bookList=query.getResultList();
		Iterator<Author> it=bookList.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next().name);
		}
	}

}
