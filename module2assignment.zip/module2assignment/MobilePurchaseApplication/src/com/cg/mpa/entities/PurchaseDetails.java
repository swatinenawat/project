package com.cg.mpa.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="purchasedetail")
public class PurchaseDetails
{
	@Id
	@Column(name="purchaseid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_purchase_id",allocationSize=1)
	private Integer purchaseId;
	
	@NotEmpty(message="Name is Mandatory")
	@Pattern(regexp="[A-Z][A-Za-z]{3,15}",message="Name should contain letters only <br> Size shold be min 3 and max 15")
	@Column(name="cname")
	private String custName;
	
	@Column(name="mailid")
	@Email(message="Enter a valid mail id")
	private String emailId;
	
	@Column(name="phoneno")
	@NotEmpty(message="Phone no is required")
	@Pattern(regexp="[0-9]{10}",message="Phone no should contain only 10 digits")
	private String phoneNo;
	
	@Column(name="purchasedate")
	@Pattern(regexp="[0-9]{2}-[A-Za-z]{3}-[0-9]{4}",message="Date must be in DD-MM-YYYY format")
	private String purchaseDate;
	
	@Column(name="mobileid")
	private Integer mobileId;
	
	public PurchaseDetails() 
	{
	
	}

	public Integer getPurchaseId()
	{
		return purchaseId;
	}

	public void setPurchaseId(Integer purchaseId)
	{
		this.purchaseId = purchaseId;
	}

	public String getCustName() 
	{
		return custName;
	}

	public void setCustName(String custName) 
	{
		this.custName = custName;
	}

	public String getEmailId() 
	{
		return emailId;
	}

	public void setEmailId(String emailId) 
	{
		this.emailId = emailId;
	}

	public String getPhoneNo() 
	{
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo)
	{
		this.phoneNo = phoneNo;
	}

	public String getPurchaseDate() 
	{
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) 
	{
		this.purchaseDate = purchaseDate;
	}

	public Integer getMobileId() 
	{
		return mobileId;
	}

	public void setMobileId(Integer mobileId)
	{
		this.mobileId = mobileId;
	}

	@Override
	public String toString() 
	{
		return "PurchaseDetails [purchaseId=" + purchaseId + ", custName="
				+ custName + ", emailId=" + emailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
	
	
	
}
