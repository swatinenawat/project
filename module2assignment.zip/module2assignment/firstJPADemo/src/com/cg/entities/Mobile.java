package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Mobile")
@NamedQueries(
		@NamedQuery(name="getMobiles",query="SELECT m FROM Mobile m WHERE m.quantity>:qty")
		)
//query included so that query gets compile as soon as entity is complied and it gives faster result
public class Mobile 
{
	@Id
	@SequenceGenerator(name="myseq",sequenceName="seq_mobiles",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	@Column(name="mobileid")
	private int mobileId;
	@Column(name="name")
	private String mobileName;
	@Column(name="price")
	private double price;
	@Column(name="quantity")
	private int quantity;
	
	
	
	public Mobile() {
		
		// TODO Auto-generated constructor stub
	}


	public Mobile(int mobileId, String mobileName, double price, int quantity) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.price = price;
		this.quantity = quantity;
	}
	
	
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", mobileName=" + mobileName
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}
	
	
	
	
	
	
}
