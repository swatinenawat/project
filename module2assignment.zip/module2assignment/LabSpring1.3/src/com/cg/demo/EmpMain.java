package com.cg.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class EmpMain {

	public static void main(String[] args) 
	{
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("demo.xml"));
		SBU sbu1 = (SBU)factory.getBean("sbu");
		System.out.println("SBU Details");
		System.out.println("-------------------------------------");
		System.out.println(sbu1);
		
	
	}

}
