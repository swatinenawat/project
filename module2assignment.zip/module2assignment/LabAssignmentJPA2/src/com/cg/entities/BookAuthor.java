package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Book_Author")
public class BookAuthor 
{
	@Id
	@Column(name="book")
	private int book;
	
	@Column(name="author")
	private int author;

	public BookAuthor()
	{
		
	}

	public BookAuthor(int book, int author) 
	{
		super();
		this.book = book;
		this.author = author;
	}

	public int getBook() 
	{
		return book;
	}

	public void setBook(int book) 
	{
		this.book = book;
	}

	public int getAuthor()
	{
		return author;
	}

	public void setAuthor(int author) {
		this.author = author;
		
	}

	@Override
	public String toString() {
		return "BookAuthor [book=" + book + ", author=" + author + "]";
	}
	
	
	
}
