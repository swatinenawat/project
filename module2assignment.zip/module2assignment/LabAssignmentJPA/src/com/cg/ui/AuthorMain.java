package com.cg.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entities.Author;


public class AuthorMain {

	public static void main(String[] args) 
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("1: Insert\t2: Delete\t3: Search\t4: update\t5 : Display\t6: Exit");
			System.out.println("Enter your choice");
			int c=sc.nextInt();
			switch(c)
			{
				case 1: Author aut=new  Author();
						System.out.println("Enter First name: ");
						aut.setFirstName(sc.next());
						System.out.println("Enter Middle name: ");
						aut.setMiddleName(sc.next());
						System.out.println("Enter Last name: ");
						aut.setLastName(sc.next());
						System.out.println("Enter Phone Number: ");
						aut.setPhoneNo(sc.nextLong());
						em.getTransaction().begin();
						em.persist(aut);
						em.getTransaction().commit();
				
						System.out.println("Author details inserted...");
						break;
				case 2: System.out.println("Enter Author Id : ");
				        int autId=sc.nextInt();
				        Author aut1 = em.find(Author.class, autId);
				        em.getTransaction().begin();
						em.remove(aut1);
						em.getTransaction().commit();
						System.out.println("Author details deleted...");
						break;
				case 3: System.out.println("Enter Author Id : ");
		        		int autId1=sc.nextInt();
		        		Author aut2 = em.find(Author.class, autId1);
		        		
		        		System.out.println(aut2);
		        		break;
				case 4: System.out.println("Enter Author Id : ");
		        		int autId2=sc.nextInt();
		        		//Author aut3 = em.find(Author.class, autId2);
		        		Author aut3=new Author();
		        		aut3.setAuthorId(autId2);
		        		System.out.println("Enter First name: ");
						aut3.setFirstName(sc.next());
						System.out.println("Enter Middle name: ");
						aut3.setMiddleName(sc.next());
						System.out.println("Enter Last name: ");
						aut3.setLastName(sc.next());
						System.out.println("Enter Phone Number: ");
						aut3.setPhoneNo(sc.nextLong());
		        		em.getTransaction().begin();
		        		em.merge(aut3);
		        		em.getTransaction().commit();
		        		System.out.println("Author details updated...");
		        		break;
				case 5: String sqry="SELECT Author from Author Author";
						TypedQuery<Author> query = em.createQuery(sqry,Author.class);
						List<Author> authorList=query.getResultList();
						Iterator<Author> it=authorList.iterator();
						while(it.hasNext())
						{
							System.out.println(it.next());
						}
						break;
		      default: System.exit(0);
			}
		}

	}

}
