package com.cg.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class HelloMain 
{

	public static void main(String[] args) 
	{
		//XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("demo.xml"));
		//HelloBean bean = (HelloBean) factory.getBean("hBean");
		//System.out.println(bean.helloWorld());
		
		//Address myAdd = (Address) factory.getBean("address");
		//System.out.println(myAdd);
		//Address myAdd1 = (Address) factory.getBean("address1");
		//System.out.println(myAdd1);
		//Employee emp = factory.getBean(Employee.class);//No need to do type casting
        //System.out.println(emp);		//Two object created one of address and employee
        
		ClassPathXmlApplicationContext factory = new ClassPathXmlApplicationContext("demo.xml");
		Employee emp1 = factory.getBean(Employee.class);
        System.out.println(emp1);
	}

}
