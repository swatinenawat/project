package com.cg.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class EmpMain {

	public static void main(String[] args) 
	{
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("demo.xml"));
		Employee emp1 = (Employee)factory.getBean("emp");
		System.out.println("Employee Details");
		System.out.println("-------------------------------------");
		System.out.print("Employee Id : ");
		System.out.println(emp1.getEmployeeId());
		System.out.print("Employee Name : ");
		System.out.println(emp1.getEmployeeName());
		System.out.print("Employee Salary : ");
		System.out.println(emp1.getSalary());
		System.out.print("Employee BU : ");
		System.out.println(emp1.getBusinessUnit());
		System.out.print("Employee Age : ");
		System.out.println(emp1.getAge());
	
	}

}
