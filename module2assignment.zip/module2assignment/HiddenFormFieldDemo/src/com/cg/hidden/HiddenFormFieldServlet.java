package com.cg.hidden;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HiddenFormFieldServlet
 */
@WebServlet("/HiddenFields")
public class HiddenFormFieldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
    public HiddenFormFieldServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name=request.getParameter("userTxt");
		String pwd=request.getParameter("pwdTxt");
		
		PrintWriter out=response.getWriter();
		
		out.println("<html><body>");
		out.println("<h1>Welcome ..."+name);
		out.println("<form action='Payment' method='post'>");
		out.println("Select Category");
		out.println("Select Product from below list");
		out.println("<input type=radio name=product value=TV>SONY Bravia");
		out.println("<input type=radio name=product value=mobile>Samsung");
		out.println("<input type=radio name=product value=ipad>IPad");
		out.println("<input type=hidden name=userName value="+name+">");
		out.println("<input type=submit value='Place Order'>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
