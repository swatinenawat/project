package com.cg.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class EmpMain {

	public static void main(String[] args) 
	{
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("demo.xml"));
		Employee emp1 = (Employee)factory.getBean("emp");
		System.out.println("Employee Details");
		System.out.println("-------------------------------------");
		System.out.println(emp1);
		
	
	}

}
