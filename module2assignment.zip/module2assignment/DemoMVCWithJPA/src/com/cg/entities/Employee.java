package com.cg.entities;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Employee")
public class Employee
{
	@Id
	@NotNull(message="EmpNo is mandatory")
	private Integer empno;
	@Column(name="empname")
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="[A-za-z]{3,15}",message="Name should contain min3 and max15 letters only")
	private String empName;
	@NotNull(message="age is mandatory")
	private Integer age;
	public Employee()
	{
		
	}
	public Integer getEmpno() 
	{
		return empno;
	}
	public void setEmpno(Integer empno)
	{
		this.empno = empno;
	}
	public String getEmpName() 
	{
		return empName;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}
	public Integer getAge() 
	{
		return age;
	}
	public void setAge(Integer age) 
	{
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", empName=" + empName + ", age="
				+ age + "]";
	}
	
}
